'use strict';

angular.module('dwarvesOfArcadiaApp')
  .service('constants', function () {
    this.url = 'http://192.168.1.128:5000/';

    return this;
  }); 